# Sketch Plugin Recommendations

## Essential Plugins (Install First)

### 1. Sketch Runner
**Purpose**: Command palette for Sketch
**Website**: https://sketchrunner.com/
**Use**: Press Cmd + ' to open, search any command
**Why**: 10x faster than navigating menus

### 2. Stark
**Purpose**: Accessibility audit
**Website**: https://getstark.co/
**Use**: Check contrast, color blindness, WCAG compliance
**Why**: Accessibility is mandatory, not optional

### 3. IconJar
**Purpose**: Icon management
**Website**: https://iconjar.com/
**Use**: Organize and export icons efficiently
**Why**: Speed up icon workflow

### 4. Abstract
**Purpose**: Version control for Sketch
**Website**: https://www.abstract.com/
**Use**: Git-like workflow, branching, merging
**Why**: Professional design file management

## Highly Recommended Plugins

### Productivity

**Rename It**
- Rename layers in batch
- Great for organizing messy documents

**Sketch Tooltips**
- Add tooltips to symbols
- Document component usage

**Content Generator**
- Fill designs with realistic content
- Names, addresses, images, text

**Faker**
- Generate mock data
- Lorem ipsum alternatives
- Localization testing

### Export & Handoff

**Sketch Measure**
- Inspect design specs
- Export CSS, Android, iOS
- Developer-friendly measurements

**Zeplin**
- Design handoff platform
- Export assets automatically
- Team collaboration

**Avocode**
- Design to code handoff
- Generate CSS, React code
- Platform-specific exports

### Design & Layout

**Auto Layout**
- Alternative to Smart Layout
- More flexible constraints
- Complex layouts

**Relay**
- Component library management
- Update symbols across files
- Design system workflow

**Sketch Symbols Resizer**
- Batch resize symbols
- Maintain proportions
- Save time on updates

### Animation & Prototyping

**Anima Toolkit**
- Motion prototyping
- Interactive prototypes
- Export to code

**Flinto for Sketch**
- Advanced prototyping
- Complex interactions
- High-fidelity animations

**ProtoPie**
- Interactive prototyping
- Sensor interactions
- Device testing

### Content & Data

**Unsplash**
- Insert royalty-free photos
- Search by keyword
- Realistic mockups

**The Noun Project**
- Access to icon library
- Import icons directly
- Icon design resources

## Plugin Management

### Best Practices
- Keep plugins updated regularly
- Remove unused plugins to improve performance
- Document essential plugins for team onboarding
- Test new plugins in separate documents first
- Backup Sketch files before major plugin updates

### Troubleshooting
- If Sketch crashes, try disabling plugins
- Restart Sketch after installing plugins
- Check plugin compatibility with Sketch version
- Report bugs to plugin developers

## Installation Commands

Using Sketch Runner:
1. Install Sketch Runner first
2. Open Sketch Runner (Cmd + ')
3. Search for "install"
4. Type plugin name or browse marketplace

Manual installation:
1. Download plugin (.zip or .sketchplugin)
2. Double-click to install
3. Sketch will open and confirm installation

## Plugin Resources

- [Sketch Plugins Directory](https://sketchplugins.com/)
- [Sketch App Sources](https://www.sketchappsources.com/)
- [Sketch Community](https://forum.sketch.com/)
- [Plugin Reviews](https://producthunt.com/search?q=sketch+plugins)
