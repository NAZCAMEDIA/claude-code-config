---
name: sketch-design-system
description: "Comprehensive Sketch design system guide including file organization, atomic design principles, naming conventions, plugins ecosystem, and best practices for macOS-only teams. Use when working with Sketch files, building component libraries, or maintaining Sketch-based design systems."
version: "1.0.0"
---

# Sketch Design System

This skill provides comprehensive guidance for working with Sketch for design system development and UI design.

## Core Philosophy

> "Design systems are not libraries of components. They are ecosystems of teams, processes, and tools that scale design across an organization."

Build design systems that scale across teams, not just component libraries.

## Sketch Overview

| Feature | Sketch | Figma Comparison |
|---------|--------|-------------------|
| Platform | macOS only | Web + iOS + Android + macOS/Windows/Linux |
| Collaboration | Limited (Sketch Cloud) | Real-time, multi-user |
| Prototyping | Basic | Advanced, micro-interactions |
| Dev Handoff | Manual / Plugins | Dev Mode integrated |
| Variables/Tokens | Plugins | Native (Design tokens) |
| Auto Layout | Smart Layout (limited) | Robust (Constraints) |
| Pricing | $9/user/month | Free + $15/editor/month |

## When to Use Sketch

✅ **Use Sketch for:**
- Iconography and illustration work
- Teams exclusively on macOS
- Individual freelancers
- Simple prototyping needs
- Integration with macOS tools

❌ **Use Figma instead for:**
- Cross-platform teams
- Real-time collaboration
- Advanced prototyping
- Large design systems with variables
- Complex component libraries

## File Organization

### Recommended Structure

```
📁 My-Design-System.sketch
├── 📁 00_FOUNDATIONS
│   ├── 🎨 Colors (symbol library)
│   ├── ✏️ Typography (symbol library)
│   ├── 📐 Spacing (symbol library)
│   └── 🧱 Materials (symbol library)
├── 📁 01_ATOMS
│   ├── 🔘 Buttons
│   ├── 📝 Inputs
│   ├── 🏷️ Badges
│   ├── 🔲 Toggles
│   └── 📎 Icons
├── 📁 02_MOLECULES
│   ├── 🎫 Cards
│   ├── 🧭 Navbar
│   ├── 📋 List Items
│   ├── ⬇️ Dropdowns
│   └── 📄 Form Fields
├── 📁 03_ORGANISMS
│   ├── 🔝 Header
│   ├── 📌 Sidebar
│   ├── 💬 Comment Thread
│   └── 📊 Data Table
├── 📁 04_TEMPLATES
│   ├── 📄 Page Template
│   ├── 🪟 Modal Template
│   └── 🎯 Hero Section
└── 📁 05_SCREENS
    ├── 🏠 Home
    ├── 👤 Profile
    └── ⚙️ Settings
```

### Naming Conventions

**Components Pattern:**
```
Component / Type / Variant / State
```

**Examples:**
```
Button / Primary / Large / Pressed
Input / Text / Error
Card / Dashboard / Compact
Icon / Action / Download
```

**Color Tokens:**
```
color / {category} / {shade}
```

**Examples:**
```
color / blue / 500
color / gray / 100
color / semantic / success
color / semantic / error
```

**Typography Tokens:**
```
font / {family} / {weight} / {size}
```

**Examples:**
```
font / SF Pro Display / Bold / 34
font / SF Pro Text / Regular / 17
font / Monospace / Medium / 14
```

## Atomic Design in Sketch

### Level 1: TOKENS (Foundations)

**Colors**
- Create color swatches as shared styles
- Use naming: `blue-500`, `gray-100`, `error-500`
- Include semantic colors: `success`, `warning`, `error`
- Light/dark mode variants

**Typography**
- Define text styles as shared styles
- Hierarchy: Display (H1-H6), Body, Caption, Overline
- Font families: SF Pro Display (headings), SF Pro Text (body)
- Weights: Regular (400), Medium (500), Semibold (600), Bold (700)

**Spacing**
- 8pt grid system
- Multiples: 4, 8, 16, 24, 32, 40, 48, 64, 96
- Scale: small, medium, large, xlarge

**Materials**
- Shadows: 3 levels (subtle, medium, strong)
- Borders: 1pt, 2pt
- Corner radius: 4pt, 8pt, 12pt, 16pt

### Level 2: ATOMS

**Buttons**
- Variants: Primary, Secondary, Ghost, Link
- Sizes: Small, Medium, Large
- States: Default, Hover, Active, Disabled, Loading
- Use Symbols with resizing options

**Inputs**
- Types: Text, Number, Email, Password, Select
- States: Default, Focus, Error, Success, Disabled
- Add placeholder and helper text options

**Icons**
- Consistent stroke width
- 24x24pt base size
- Use Symbol instances with overrides
- Group by category: navigation, action, social

**Badges & Tags**
- Variants: Default, Success, Warning, Error
- Sizes: Small, Medium
- Rounded corners: 4pt, round

### Level 3: MOLECULES

**Cards**
- Content variants: text-only, with image, with action
- Elevation: flat, shadow-sm, shadow-md
- Use Smart Layout for auto-resize

**Navbar**
- Navigation elements: logo, links, actions
- Responsive variants: desktop, mobile
- Use symbols with layer overrides

**List Items**
- Elements: icon, title, subtitle, action, badge
- Interaction states: default, hover, pressed
- Grouped vs. standalone

**Form Fields**
- Label + Input + Error Message
- Validation states visual feedback
- Group in symbols for consistency

### Level 4: ORGANISMS

**Header**
- Navigation, user actions, notifications
- Sticky vs. scroll behavior
- Dark mode variant

**Sidebar**
- Navigation hierarchy
- Collapsible sections
- Active state indicators

**Data Table**
- Sortable columns
- Row actions
- Pagination controls

### Level 5: TEMPLATES

**Page Templates**
- Base layout structure
- Content area with consistent padding
- Footer, header placement

**Modal Templates**
- Backdrop overlay
- Close button placement
- Animation options

### Level 6: SCREENS

Use templates + components to build complete screens.

## Best Practices

### Symbol Management
- Use symbols for all repeatable elements
- Enable "Include in Library" for system-wide symbols
- Use Smart Layout for auto-resizing components
- Set proper resizing constraints (left/top pinned)

### Layer Organization
- Groups with descriptive names
- Color-code by category
- Keep layer panel clean (delete unused layers)
- Use artboards for screens

### Style Management
- Use shared styles for text, fills, borders, shadows
- Name styles descriptively: `Text / H1 / Bold`
- Update styles globally, not per-instance
- Document style usage in notes

### Version Control
- Use external VCS: Git + Abstract
- Keep `.sketch` files in repo
- Document changes in commit messages
- Tag releases: `v1.0.0`, `v1.1.0`

### Collaboration
- Use Sketch Cloud for sharing
- Document decisions in design specs
- Regular design reviews
- Comment directly on layers

## Essential Plugins

### Productivity
**Sketch Runner**
- Shortcuts for everything
- Command palette: Cmd + '
- Install plugins, run commands quickly

**Sketch Tooltips**
- Add tooltips to symbols
- Document component usage in tooltip

**Stark**
- Accessibility audit
- Color contrast checker
- WCAG compliance

### Asset Management
**IconJar**
- Organize icon library
- Export to multiple formats
- Sync with Sketch document

**Abstract**
- Version control for Sketch
- Collaboration workflow
- Branches and merging

### Inspection
**Sketch Measure**
- Inspect design specs
- Export CSS, Android, iOS specs
- Handoff to developers

**Zeplin**
- Design handoff platform
- Export assets automatically
- Developer communication

### Animation
**Anima Toolkit**
- Motion prototyping
- Interactive prototypes
- Export to code

### Content
**Content Generator**
- Fill designs with realistic content
- Names, addresses, images
- Test different data scenarios

**Faker**
- Generate mock data
- Lorem ipsum alternatives
- Localization testing

## Smart Layout (Sketch's Auto Layout)

### Enabling Smart Layout
1. Select a symbol
2. Click "Smart Layout" in inspector
3. Choose: Horizontal or Vertical
3. Set spacing between layers

### Best Practices
- Use for components with dynamic content
- Set appropriate padding
- Test with different content lengths
- Combine with resizing constraints

### Limitations
- Less powerful than Figma's Auto Layout
- No constraints for specific layers
- Better for simple components than complex layouts

## Exporting

### Export Settings
- Use `1x`, `2x`, `3x` scales
- Format: PNG for icons, SVG for scalable graphics
- Suffix: `@2x`, `@3x`
- Transparent background for assets

### Batch Export
- Export entire artboards
- Export selected layers
- Use export presets for consistency

### Code Export
- Install plugins for CSS/React/Android export
- Sketch Measure for comprehensive specs
- Anima for interactive prototypes

## Workflow

### 1. Foundations Setup
Create token library:
- Define color palette
- Create typography system
- Establish spacing scale
- Set material properties

### 2. Component Building
Build atomic components:
- Create symbols for repeatable elements
- Use shared styles for consistency
- Document variants and states
- Test with different content

### 3. System Assembly
Compose larger patterns:
- Build molecules from atoms
- Create organisms from molecules
- Develop templates for pages
- Document usage guidelines

### 4. Maintenance
Keep system current:
- Version control changes
- Regular audits for consistency
- Gather user feedback
- Iterate and improve

## When to Use This Skill

Use this skill when:
- Creating or maintaining Sketch-based design systems
- Building component libraries in Sketch
- Setting up Sketch file organization
- Configuring plugins and workflows
- Preparing handoff to developers

## Quality Checklist

Before considering a design system complete:
- [ ] All components have proper symbol structure
- [ ] Naming conventions applied consistently
- [ ] Shared styles used for text/colors/borders
- [ ] Smart Layout enabled for responsive components
- [ ] Documentation exists for each component
- [ ] Accessibility standards met (Stark plugin)
- [ ] Export settings configured
- [ ] Plugins installed and configured
- [ ] Version control in place (Abstract/Git)
- [ ] Team guidelines documented

## References

- [Sketch Documentation](https://www.sketch.com/docs/)
- [Sketch Plugins Directory](https://sketchplugins.com/)
- [Atomic Design by Brad Frost](https://atomicdesign.bradfrost.com/)
- [Abstract](https://www.abstract.com/)
- [Sketch Measure](https://measure.sketchapp.com/)
