# Design Token Examples

## Color Token Set

```json
{
  "color": {
    "primary": {
      "50": "#E8F4FF",
      "100": "#D1E9FF",
      "200": "#A3D4FF",
      "300": "#75BFFF",
      "400": "#47A9FF",
      "500": "#007AFF",
      "600": "#0056CC",
      "700": "#004299",
      "800": "#002D66",
      "900": "#001833"
    },
    "neutral": {
      "50": "#F8F9FA",
      "100": "#E9ECEF",
      "200": "#DEE2E6",
      "300": "#CED4DA",
      "400": "#ADB5BD",
      "500": "#6C757D",
      "600": "#495057",
      "700": "#343A40",
      "800": "#212529",
      "900": "#1A1A1A"
    },
    "semantic": {
      "success": {
        "50": "#D1FAE5",
        "500": "#10B981",
        "900": "#064E3B"
      },
      "warning": {
        "50": "#FEF3C7",
        "500": "#F59E0B",
        "900": "#78350F"
      },
      "error": {
        "50": "#FEE2E2",
        "500": "#EF4444",
        "900": "#7F1D1D"
      },
      "info": {
        "50": "#DBEAFE",
        "500": "#3B82F6",
        "900": "#1E3A8A"
      }
    }
  }
}
```

## Typography Token Set

```json
{
  "font": {
    "family": {
      "display": "'SF Pro Display', -apple-system, sans-serif",
      "body": "'SF Pro Text', -apple-system, sans-serif",
      "monospace": "'SF Mono', 'Monaco', monospace"
    },
    "size": {
      "display-xl": "48px",
      "display-lg": "40px",
      "display-md": "34px",
      "heading-1": "32px",
      "heading-2": "28px",
      "heading-3": "24px",
      "heading-4": "20px",
      "heading-5": "18px",
      "body-lg": "17px",
      "body-md": "15px",
      "body-sm": "13px",
      "caption": "11px",
      "overline": "10px"
    },
    "weight": {
      "light": "300",
      "regular": "400",
      "medium": "500",
      "semibold": "600",
      "bold": "700"
    },
    "line-height": {
      "display": "1.2",
      "heading": "1.3",
      "body": "1.5",
      "compact": "1.4"
    },
    "letter-spacing": {
      "display": "-0.02em",
      "heading": "-0.01em",
      "body": "0",
      "uppercase": "0.05em"
    }
  }
}
```

## Spacing Token Set

```json
{
  "spacing": {
    "0": "0",
    "1": "4px",
    "2": "8px",
    "3": "12px",
    "4": "16px",
    "5": "20px",
    "6": "24px",
    "8": "32px",
    "10": "40px",
    "12": "48px",
    "16": "64px",
    "20": "80px",
    "24": "96px",
    "32": "128px",
    "40": "160px"
  }
}
```

## Border Radius Token Set

```json
{
  "border-radius": {
    "none": "0",
    "sm": "4px",
    "md": "8px",
    "lg": "12px",
    "xl": "16px",
    "2xl": "24px",
    "full": "9999px"
  }
}
```

## Shadow Token Set

```json
{
  "shadow": {
    "none": "none",
    "sm": "0 1px 2px rgba(0, 0, 0, 0.05)",
    "md": "0 4px 6px rgba(0, 0, 0, 0.1)",
    "lg": "0 10px 15px rgba(0, 0, 0, 0.1)",
    "xl": "0 20px 25px rgba(0, 0, 0, 0.15)"
  }
}
```

## Motion Token Set

```json
{
  "duration": {
    "instant": "100ms",
    "fast": "150ms",
    "base": "300ms",
    "slow": "500ms",
    "slower": "750ms"
  },
  "easing": {
    "linear": "linear",
    "ease-in": "ease-in",
    "ease-out": "ease-out",
    "ease-in-out": "cubic-bezier(0.4, 0, 0.2, 1)",
    "ease-elastic": "cubic-bezier(0.175, 0.885, 0.32, 1.275)",
    "ease-spring": "cubic-bezier(0.25, 0.1, 0.25, 1.0)"
  }
}
```

## Z-Index Token Set

```json
{
  "z-index": {
    "dropdown": 1000,
    "sticky": 1020,
    "fixed": 1030,
    "modal-backdrop": 1040,
    "modal": 1050,
    "popover": 1060,
    "tooltip": 1070
  }
}
```

## Breakpoint Token Set

```json
{
  "breakpoint": {
    "xs": "320px",
    "sm": "640px",
    "md": "768px",
    "lg": "1024px",
    "xl": "1280px",
    "2xl": "1536px"
  }
}
```

## Using Tokens in Different Platforms

### CSS Custom Properties
```css
:root {
  --color-primary-500: #007AFF;
  --spacing-4: 16px;
  --font-body: 'SF Pro Text', sans-serif;
}

.button {
  background: var(--color-primary-500);
  padding: var(--spacing-4);
  font-family: var(--font-body);
}
```

### Tailwind CSS
```js
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        primary: {
          500: '#007AFF',
        }
      },
      spacing: {
        '4': '16px',
      }
    }
  }
}

// Usage
<div className="bg-primary-500 p-4">Button</div>
```

### Styled Components
```tsx
import styled from 'styled-components'

const Button = styled.button`
  background: ${({ theme }) => theme.colors.primary[500]};
  padding: ${({ theme }) => theme.spacing[4]};
  font-family: ${({ theme }) => theme.fonts.body};
`
```

### React Native
```js
// tokens.js
export const colors = {
  primary: {
    500: '#007AFF',
  }
}

export const spacing = {
  4: 16,
}

// Usage
const Button = styled.View`
  background: ${colors.primary[500]};
  padding: ${spacing[4]}px;
`
```

### Swift/iOS
```swift
// DesignTokens.swift
extension UIColor {
    static let primary500 = UIColor(hex: "#007AFF")
}

extension CGFloat {
    static let spacing4: CGFloat = 16.0
}

// Usage
button.backgroundColor = .primary500
button.padding = .spacing4
```

### Android/Kotlin
```kotlin
// DesignTokens.kt
object DesignTokens {
    val primary500 = Color.parseColor("#007AFF")
    val spacing4 = 16.dp
}

// Usage
button.setBackgroundColor(DesignTokens.primary500)
button.setPadding(DesignTokens.spacing4)
```

## Token Naming Best Practices

### Do's
✅ Semantic names: `primary-500`, `text-body`
✅ Consistent structure: `category-property-variant`
✅ Platform-agnostic: `border-radius-md` not `rounded-md`
✅ Scale-based: `100-900` for colors, `xs-xl` for spacing

### Don'ts
❌ Literal names: `nice-blue`, `big-font`
❌ Tool-specific: `text-base`, `rounded-lg` (Tailwind-specific)
❌ Inconsistent patterns: mixing naming conventions
❌ Magic numbers: hardcoded values
