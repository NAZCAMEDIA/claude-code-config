---
name: atomic-design-system
description: "Guide for building scalable design systems using Atomic Design methodology (TOKENS → ATOMS → MOLECULES → ORGANISMS → TEMPLATES → SCREENS). Covers design tokens, component documentation, platform-agnostic systems, and best practices for design system maintenance and governance."
version: "1.0.0"
---

# Atomic Design System

This skill provides comprehensive guidance for building scalable design systems using the Atomic Design methodology.

## Core Philosophy

> "Atomic design is a methodology for creating design systems. There are five distinct levels in atomic design: atoms, molecules, organisms, templates, and pages." - Brad Frost

Design systems are living ecosystems that scale with products and teams.

## Atomic Design Architecture

```
TOKENS (Foundations)
    ↓
ATOMS (Primitives)
    ↓
MOLECULES (Simple components)
    ↓
ORGANISMS (Complex sections)
    ↓
TEMPLATES (Layouts)
    ↓
SCREENS (Complete pages)
```

## Level 1: TOKENS (Foundations)

### What Are Design Tokens?

Design tokens are the visual design atoms of your design system. They are named entities that store visual design attributes.

### Token Categories

**Color Tokens**
```json
{
  "color": {
    "primary": {
      "500": "#007AFF",
      "600": "#0056CC"
    },
    "neutral": {
      "100": "#F8F9FA",
      "900": "#1A1A1A"
    },
    "semantic": {
      "success": "#10B981",
      "warning": "#F59E0B",
      "error": "#EF4444"
    }
  }
}
```

**Typography Tokens**
```json
{
  "font": {
    "family": {
      "display": "SF Pro Display",
      "body": "SF Pro Text",
      "monospace": "SF Mono"
    },
    "size": {
      "heading-1": "34px",
      "heading-2": "28px",
      "body": "17px",
      "caption": "13px"
    },
    "weight": {
      "regular": "400",
      "medium": "500",
      "semibold": "600",
      "bold": "700"
    },
    "line-height": {
      "tight": "1.2",
      "normal": "1.5",
      "relaxed": "1.75"
    }
  }
}
```

**Spacing Tokens**
```json
{
  "spacing": {
    "xs": "4px",
    "sm": "8px",
    "md": "16px",
    "lg": "24px",
    "xl": "32px",
    "2xl": "48px",
    "3xl": "64px"
  }
}
```

**Material Tokens**
```json
{
  "shadow": {
    "sm": "0 1px 2px rgba(0,0,0,0.05)",
    "md": "0 4px 6px rgba(0,0,0,0.1)",
    "lg": "0 10px 15px rgba(0,0,0,0.1)"
  },
  "border-radius": {
    "sm": "4px",
    "md": "8px",
    "lg": "12px",
    "xl": "16px",
    "full": "9999px"
  },
  "border": {
    "thin": "1px",
    "medium": "2px",
    "thick": "4px"
  }
}
```

**Motion Tokens**
```json
{
  "duration": {
    "fast": "150ms",
    "base": "300ms",
    "slow": "500ms"
  },
  "easing": {
    "ease-in-out": "cubic-bezier(0.4, 0, 0.2, 1)",
    "ease-out": "cubic-bezier(0, 0, 0.2, 1)",
    "spring": "cubic-bezier(0.175, 0.885, 0.32, 1.275)"
  }
}
```

### Token Principles

**1. Naming Convention**
- Use semantic names: `primary-500` not `nice-blue`
- Platform-agnostic: `border-radius-md` not `rounded-md`
- Descriptive: `spacing-md` not `p4`

**2. Hierarchy**
- Group by category: color, spacing, typography
- Use scales: 100-900 for colors, xs-xl for spacing
- Document relationships between tokens

**3. Documentation**
- Include use cases: when to use each token
- Provide examples: color combinations, type scales
- Update when design system evolves

**4. Versioning**
- Use semantic versioning: v1.0.0, v1.1.0, v2.0.0
- Breaking changes: major version bump
- Backward compatible: minor/patch

## Level 2: ATOMS

### What Are Atoms?

Atoms are the basic building blocks of matter, applied to web interfaces. They can't be broken down further without losing their meaning.

### Common Atoms

**Button Atom**
- Variants: Primary, Secondary, Ghost, Link
- Sizes: Small, Medium, Large
- States: Default, Hover, Active, Disabled, Loading
- Props: label, icon, loading, disabled, onClick

**Input Atom**
- Types: Text, Number, Email, Password, Search
- States: Default, Focus, Error, Success, Disabled
- Props: label, placeholder, value, onChange, error

**Icon Atom**
- Consistent style: outline, filled, duotone
- Sizes: 16px, 20px, 24px, 32px
- Props: name, size, color

**Badge Atom**
- Variants: Default, Success, Warning, Error
- Sizes: Small, Medium
- Props: label, variant

**Toggle Atom**
- States: On, Off, Disabled
- Props: checked, onChange, disabled

### Atom Documentation Template

```markdown
# Button

## Description
A clickable element that triggers an action.

## Props
| Prop | Type | Default | Description |
|------|------|---------|-------------|
| variant | 'primary' \| 'secondary' \| 'ghost' | 'primary' | Visual variant |
| size | 'sm' \| 'md' \| 'lg' | 'md' | Button size |
| disabled | boolean | false | Disabled state |
| loading | boolean | false | Loading state |
| onClick | function | - | Click handler |
| children | ReactNode | - | Button content |

## Variants
- **Primary**: Main action button
- **Secondary**: Secondary action
- **Ghost**: Minimal visual weight

## Usage
```
<Button variant="primary" size="md">Submit</Button>
```

## Accessibility
- Keyboard focusable (Tab)
- ARIA attributes support
- Minimum touch target: 44x44px
```

## Level 3: MOLECULES

### What Are Molecules?

Molecules are groups of atoms bonded together and are the smallest fundamental units of a compound. They take on distinct characteristics of their own.

### Common Molecules

**Card Molecule**
- Header: title, subtitle, actions
- Body: content, media
- Footer: metadata, links
- Props: title, subtitle, children, footer, variant

**Navbar Molecule**
- Logo/Brand element
- Navigation links
- User actions
- Responsive toggle
- Props: brand, links, userMenu, onMenuToggle

**List Item Molecule**
- Primary content: title, subtitle
- Media: icon, avatar
- Actions: button, checkbox, menu
- Props: title, subtitle, icon, action, onClick

**Form Field Molecule**
- Label atom
- Input atom
- Error message
- Helper text
- Props: label, error, helper, required

**Dropdown Molecule**
- Trigger button
- Menu items
- Icons for items
- Props: trigger, items, onSelect

### Molecule Design Principles

**1. Composition**
- Combine atoms logically
- Maintain atomic reusability
- Avoid over-composition

**2. Flexibility**
- Support optional elements
- Use slot patterns
- Allow custom content

**3. Consistency**
- Follow spacing tokens
- Use consistent border radius
- Maintain visual hierarchy

## Level 4: ORGANISMS

### What Are Organisms?

Organisms are complex, relatively distinct sections of an interface. They form distinct sections of the interface.

### Common Organisms

**Header Organism**
- Logo/branding
- Navigation (navbar)
- User menu/actions
- Search bar
- Notifications

**Sidebar Organism**
- Navigation tree
- Collapsible sections
- Active state indicators
- Footer content

**Comment Thread Organism**
- Comments list
- Reply form
- User avatars
- Timestamps
- Actions (edit, delete, like)

**Data Table Organism**
- Header row (sortable)
- Data rows
- Pagination controls
- Row actions
- Filter controls

**Form Organism**
- Multiple form fields (molecules)
- Submit/reset actions
- Validation feedback
- Progress indicators

### Organism Design Principles

**1. Section Boundaries**
- Clear visual separation
- Consistent spacing
- Logical grouping

**2. Information Density**
- Balance content vs. whitespace
- Progressive disclosure
- Mobile responsiveness

**3. State Management**
- Local state for isolated behavior
- Global state for cross-section logic
- Prop drilling vs. context

## Level 5: TEMPLATES

### What Are Templates?

Templates consist mostly of groups of organisms stitched together to form pages. It's here where we start to see the layout coming together.

### Template Structure

**Page Template**
```
┌─────────────────────────┐
│ Header Organism        │
├─────────────────────────┤
│                       │
│ Main Content Area     │
│ (Organisms)          │
│                       │
├─────────────────────────┤
│ Footer Organism        │
└─────────────────────────┘
```

**Modal Template**
- Overlay backdrop
- Modal container
- Header (title, close)
- Body content
- Footer (actions)

**Empty State Template**
- Illustration or icon
- Title
- Description
- Call-to-action

**Loading Template**
- Skeleton screens
- Progress indicators
- Loading messages

### Template Principles

**1. Layout Consistency**
- Fixed header/footer
- Scrollable content area
- Responsive breakpoints

**2. Content Slots**
- Named slots for flexibility
- Default content
- Override capability

**3. Responsive Design**
- Mobile-first approach
- Breakpoint tokens
- Adaptive layouts

## Level 6: SCREENS

### What Are Screens?

Screens are specific instances of templates. Place content into templates to build actual pages.

### Screen Development

**Dashboard Screen**
```
Dashboard Template
├── Header: "Dashboard"
├── Stats Cards (4x)
├── Chart Organism
└── Recent Activity Table
```

**Settings Screen**
```
Settings Template
├── Header: "Settings"
├── Navigation (Sidebar)
└── Sections (Forms)
    ├── Profile
    ├── Notifications
    └── Security
```

**Product List Screen**
```
Product List Template
├── Header: "Products"
├── Filter Bar
├── Product Grid
└── Pagination
```

## Design System Documentation

### Component Documentation

**Required Sections:**
1. **Description**: What the component does
2. **Props**: All properties with types and defaults
3. **Variants**: Available variants
4. **States**: Default, hover, active, disabled
5. **Usage**: Code examples
6. **Accessibility**: ARIA, keyboard, screen reader

### Style Guide

**Sections:**
- Typography: all type scales and usage
- Color palette: semantic color usage
- Spacing: spacing scale and usage
- Iconography: icon set and usage
- Imagery: photography, illustration guidelines
- Motion: animation and transition guidelines

### Usage Guidelines

**When to Use Components:**
- Card: Group related content
- Button: Primary and secondary actions
- Input: Form data entry
- Badge: Status indicators
- Modal: Contextual content, focus

**When NOT to Use:**
- Don't mix component families
- Don't create custom variants without documentation
- Don't use components for layout only

## Design System Governance

### Team Roles

**Design System Lead**
- Overall vision and direction
- Component approval
- Team coordination

**Component Maintainer**
- Individual component ownership
- Bug fixes and updates
- Documentation updates

**Contributor**
- Propose new components
- Report issues
- Write documentation

### Contribution Workflow

1. **Proposal**: Submit RFC for new component
2. **Review**: Design system team reviews
3. **Implementation**: Build component and tests
4. **Documentation**: Write complete docs
5. **Approval**: Merge to main system

### Versioning Strategy

- **Major (X.0.0)**: Breaking changes
- **Minor (0.X.0)**: New features, backward compatible
- **Patch (0.0.X)**: Bug fixes, documentation

### Maintenance

**Regular Tasks:**
- Audit component usage
- Remove unused components
- Update dependencies
- Fix accessibility issues
- Gather user feedback

## Platform Implementation

### CSS Variables
```css
:root {
  --color-primary-500: #007AFF;
  --spacing-md: 16px;
  --font-body: 'SF Pro Text', sans-serif;
  --border-radius-md: 8px;
}

.component {
  background: var(--color-primary-500);
  padding: var(--spacing-md);
  border-radius: var(--border-radius-md);
}
```

### Tailwind CSS
```js
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        primary: {
          500: '#007AFF',
          600: '#0056CC',
        },
      },
      spacing: {
        'md': '16px',
      },
      borderRadius: {
        'md': '8px',
      },
    },
  },
}
```

### React/TypeScript
```tsx
interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  children: React.ReactNode;
  onClick?: () => void;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  disabled = false,
  children,
  onClick,
}) => {
  return (
    <button
      className={`btn btn-${variant} btn-${size}`}
      disabled={disabled}
      onClick={onClick}
    >
      {children}
    </button>
  );
};
```

## When to Use This Skill

Use this skill when:
- Building a new design system
- Extending an existing design system
- Creating component libraries
- Documenting design systems
- Onboarding teams to design systems
- Refactoring UI to use design system

## Quality Checklist

Before releasing a design system component:
- [ ] Token-based (no hardcoded values)
- [ ] Properly documented
- [ ] Accessibility compliant
- [ ] Responsive tested
- [ ] Keyboard navigable
- [ ] Screen reader tested
- [ ] Has unit tests
- [ ] Has visual regression tests
- [ ] Versioned
- [ ] Approved by design system team

## Common Pitfalls

**❌ Avoid:**
- Hardcoded colors/sizes
- Components with too many variants
- Missing documentation
- No accessibility testing
- Breaking changes without version bump
- Over-engineering simple components

**✅ Instead:**
- Use design tokens
- Keep variants minimal and documented
- Write comprehensive docs
- Test with screen readers
- Follow semantic versioning
- Start simple, iterate

## References

- [Atomic Design by Brad Frost](https://atomicdesign.bradfrost.com/)
- [Design Systems Handbook by Figma](https://www.figma.com/resources/design-systems-handbook/)
- [Design Tokens W3C Community Group](https://www.w3.org/community/design-tokens/)
- [Component-Driven Development](https://www.componentdriven.org/)
- [Refactoring UI](https://www.refactoringui.com/)
