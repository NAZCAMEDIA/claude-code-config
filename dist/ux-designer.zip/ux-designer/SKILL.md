---
name: ux-designer
description: "Comprehensive UI/UX design guide covering hard skills (prototyping, visual design, user research, information architecture, design systems), soft skills (collaboration, communication, storytelling, leadership), and essential non-design skills (business acumen, technical literacy). Use when designing user interfaces, conducting user research, building design systems, or planning product UX."
version: "1.0.0"
---

# UI/UX Designer

This skill provides comprehensive guidance for UI/UX design work, spanning from visual design to strategic product thinking.

## Core Philosophy

> "Design is not just what it looks like and feels like. Design is how it works." - Steve Jobs

Design with the user in mind first, business goals second, and aesthetics in service of both.

## Hard Skills (Technical)

### 1. Prototyping (Fundamental)

**Wireframing**
- Low-fidelity: Sketch layouts quickly, focus on structure and content hierarchy
- Tool-agnostic: Paper, Balsamiq, Figma, Sketch, XD
- Goal: Rapid iteration and concept validation

**Low/High-fidelity Prototypes**
- **Low-fi**: grayscale, basic shapes, no polish (exploration phase)
- **High-fi**: pixel-perfect, interactive, final assets (presentation phase)
- **Interactive protos**: clickable flows, micro-interactions, state transitions

**Interactive Prototyping**
- Define user flows before building
- Test critical paths: onboarding, core features, error states
- Use prototypes for stakeholder alignment and user testing

### 2. Visual Design (Fundamental)

**Layout**
- Grid systems: 8pt grid (industry standard)
- Alignment: consistent spacing, visual rhythm
- Hierarchy: size, weight, color, position guide attention

**Typography**
- Font pairings: Display (headings) + Body (text)
- Scales: Modular scale or responsive typography
- Readability: line height (1.4-1.6), line length (60-75 chars)

**Color Theory**
- Color psychology: blue = trust, red = urgency, green = success
- Contrast: WCAG AA minimum 4.5:1 for text
- Accessibility: test with color blindness simulators
- Palettes: primary, secondary, semantic colors

**Icon Design**
- Consistent style: line, filled, duotone
- Grid alignment: maintain pixel-perfect alignment
- Meaningful: icons should be intuitive, not decorative

### 3. User Research (Intermediate)

**Interviews**
- Open-ended questions: "Tell me about how you..."
- Follow-up: "Why is that important to you?"
- Capture quotes: direct user words for empathy

**Usability Testing**
- Task-based: "Find and purchase X"
- Think-aloud: participants narrate actions
- Observe, don't lead: watch natural behavior

**Analytics**
- Quantitative: bounce rates, time on task, conversion
- Qualitative: heatmaps, session recordings, surveys
- Context: combine with qualitative research for insights

### 4. Information Architecture (Intermediate)

**Sitemaps**
- Taxonomy: logical grouping of content
- Navigation: user's mental model vs. site structure
- Depth: balance breadth vs. depth (3-4 levels max)

**User Flows**
- Entry points: landing pages, search, direct links
- Decision points: user choices and branches
- Exit points: completion, abandonment, off-site

### 5. Design Systems (Advanced)

**Tokens**
- Design tokens: colors, typography, spacing, shadows
- Platform-agnostic: JSON, YAML, CSS variables
- Versioning: semver for breaking changes

**Components**
- Atomic design: atoms → molecules → organisms
- Documented: props, variants, examples
- Accessible: keyboard, screen reader, focus management

**Documentation**
- Storybook: interactive component showcase
- Usage guidelines: when and how to use components
- Contributing: onboarding for designers and developers

### 6. Motion Design (Advanced)

**Micro-interactions**
- Feedback: button presses, form validation
- Delight: load states, success animations
- Principles: follow-through, easing, anticipation

**Animations**
- Purpose-driven: communicate state change, guide attention
- Duration: 200-300ms for UI, longer for storytelling
- Easing: ease-in-out for natural feel

### 7. AI-Assisted Design (Emerging)

**Generar Assets**
- Generate variations: explore options quickly
- Scale production: resize, recolor, export
- Consistency: AI enforces design tokens

**Prompts**
- Be specific: "Design a clean, modern mobile app login screen..."
- Include constraints: "Use 8pt grid, primary color #007AFF..."
- Iterate: refine prompt based on results

### 8. Accessibility (A11y) (Emerging)

**WCAG Compliance**
- WCAG 2.1 AA: minimum standard
- Perceivable: color, text, audio alternatives
- Operable: keyboard, timing, seizures
- Understandable: language, consistency, error recovery
- Robust: compatible with assistive tech

**Screen Readers**
- Label all interactive elements
- Semantic HTML: proper heading hierarchy
- Focus order: logical tab navigation
- Live regions: announce dynamic content

## Soft Skills

### Collaboration
- **Design Reviews**: present work, receive feedback constructively
- **Feedback Loops**: iterate based on critiques
- **Teamwork**: work cross-functionally with PM, eng, marketing

### Communication
- **Presentation**: clearly explain design decisions
- **Stakeholder Management**: align expectations, manage tradeoffs
- **Visual Communication**: use diagrams, mockups, prototypes

### Prioritization
- **Backlog Management**: rank features by impact/effort
- **Feature Prioritización**: MoSCoW, RICE, Kano model
- **Design Debt**: address systematically like tech debt

### Storytelling
- **Pitching Ideas**: narrative-driven presentations
- **Design Rationale**: explain "why" not just "what"
- **User Stories**: empathy through narrative

### Leadership
- **Design Mentoring**: grow other designers
- **Project Ownership**: end-to-end responsibility
- **Advocacy**: champion user needs

## Non-Design Critical Skills

### Business Acumen
- Understand KPIs: conversion, retention, churn
- Design ROI: measure impact of design changes
- Tradeoffs: balance user needs with business constraints

### Project Management
- Estimations: effort and duration
- Roadmaps: plan design work across releases
- Stakeholders: manage expectations and communication

### Technical Literacy
- Understand implementation: what's feasible
- Handoff: specs, assets, developer conversations
- Technical constraints: work within platform limitations

### Problem Framing
- Define the problem: before solving it
- Reframing: look at from multiple angles
- Root cause: not symptoms, but underlying issues

## Workflow

### 1. Discovery
- **Research**: interviews, analytics, competitor analysis
- **Define**: problem statement, user needs, success metrics
- **Align**: stakeholders on goals and constraints

### 2. Ideation
- **Explore**: multiple concepts, quantity over quality
- **Sketch**: low-fi wireframes, storyboards
- **Converge**: select and refine best ideas

### 3. Design
- **Iterate**: low-fi → high-fi, test along the way
- **Document**: design systems, specifications
- **Validate**: usability testing, feedback loops

### 4. Delivery
- **Handoff**: specs, assets, implementation support
- **Launch**: collaborate with engineering
- **Measure**: track KPIs, iterate post-launch

## When to Use This Skill

Use this skill when:
- Designing user interfaces (web, mobile, desktop)
- Conducting user research or usability testing
- Building or maintaining design systems
- Planning product UX strategy
- Creating design documentation
- Reviewing designs for quality and accessibility

## Common Patterns

### Design Review Checklist
- [ ] User needs addressed?
- [ ] Accessibility standards met?
- [ ] Consistent with design system?
- [ ] Tested with users?
- [ ] Technical feasibility validated?

### Presentation Structure
1. **Problem**: what we're solving
2. **Process**: research and exploration
3. **Solution**: design decisions
4. **Impact**: expected outcomes

## References

- [Atomic Design by Brad Frost](https://atomicdesign.bradfrost.com/)
- [Refactoring UI](https://www.refactoringui.com/)
- [Design Systems Handbook by Figma](https://www.figma.com/resources/design-systems-handbook/)
- [WCAG 2.1 Guidelines](https://www.w3.org/WAI/WCAG21/quickref/)
- [Laws of UX](https://lawsofux.com/)
