# UI/UX Best Practices Checklist

## Color & Contrast

- [ ] WCAG 2.1 AA compliance (4.5:1 contrast minimum)
- [ ] Color blindness tested (Protanopia, Deuteranopia, Tritanopia)
- [ ] Semantic color usage (success = green, error = red)
- [ ] Light/dark mode support
- [ ] High contrast mode support

## Typography

- [ ] Max 3 font weights per screen
- [ ] Consistent type scale (modular scale)
- [ ] Line height 1.4-1.6 for body text
- [ ] Line length 60-75 characters optimal
- [ ] Hierarchy clear (H1-H6, body, caption)

## Spacing & Layout

- [ ] 8pt grid system
- [ ] Consistent spacing tokens (4, 8, 16, 24, 32)
- [ ] Visual rhythm (consistent gaps)
- [ ] Content hierarchy (size, weight, color, position)
- [ ] White space for breathing room

## Accessibility

- [ ] Keyboard navigation (Tab, Enter, Escape)
- [ ] Focus indicators visible
- [ ] ARIA labels on interactive elements
- [ ] Screen reader tested (VoiceOver, NVDA)
- [ ] Touch targets minimum 44x44px

## Mobile

- [ ] Touch-friendly sizing (min 44px)
- [ ] Swipe gestures considered
- [ ] Single thumb reachability
- [ ] Loading states for network delays
- [ ] Offline fallback states

## Performance

- [ ] Optimized images (WebP, proper sizing)
- [ ] Lazy loading for long content
- [ ] Skeleton screens for loading states
- [ ] Progress indicators for async operations
- [ ] Efficient animations (60fps)

## Content

- [ ] Clear, concise copy
- [ ] Active voice preferred
- [ ] Consistent terminology
- [ ] Error messages are helpful, not technical
- [ ] Empty states guide users to next action

## Micro-interactions

- [ ] Hover feedback on interactive elements
- [ ] Pressed state feedback
- [ ] Focus state visible
- [ ] Loading states for async actions
- [ ] Success/error feedback after actions

## Forms

- [ ] Clear labels above fields
- [ ] Helpful placeholders (not labels)
- [ ] Inline validation feedback
- [ ] Clear error messages with fix suggestions
- [ ] Submit button clearly labeled

## Navigation

- [ ] Breadcrumbs for deep hierarchies
- [ ] Back button available
- [ ] Current page indicated in nav
- [ ] Search when content > 50 items
- [ ] Clear call-to-action on key pages

## Data Display

- [ ] Large numbers formatted (1K, 1M, 1B)
- [ ] Dates localized (relative time when recent)
- [ ] Tables have sorting/filtering
- [ ] Empty states for no data
- [ ] Loading states for data fetching

## States

- [ ] Loading state (skeleton or spinner)
- [ ] Empty state (illustration + CTA)
- [ ] Error state (message + retry)
- [ ] Success state (confirmation)
- [ ] Disabled state (visually clear)
